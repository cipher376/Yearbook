import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'src/app/shared/services/providers/authentication/auth-guard.service';

const routes: Routes = [
  {
    canActivate: [AuthGuardService],
    path: '',
    pathMatch: 'full',
    redirectTo: 'home'
  },
  {
    canActivate: [AuthGuardService],
    path: 'chat-home',
    loadChildren: './chat-home/chat-home.module#ChatHomePageModule'
  },
  {
    canActivate: [AuthGuardService],
    path: 'chat-private',
    loadChildren: './chat-private/chat-private.module#ChatPrivatePageModule'
  },
  {
    canActivate: [AuthGuardService],
    path: 'chat-public',
    loadChildren: './chat-public/chat-public.module#ChatPublicPageModule'
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    CommonModule
  ],
  exports: [RouterModule]
})
export class ChatRoutingModule { }
