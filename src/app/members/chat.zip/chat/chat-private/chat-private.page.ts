
import { Component, OnInit, ViewChild, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MenuController, LoadingController, IonContent, ActionSheetController } from '@ionic/angular';
import { Device } from '@ionic-native/device/ngx';
import { AlertController, Platform } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { ChatObj } from '../models/chat';
import { ChatMessage, FameIdentity, ChatRoom, FameUser } from 'src/app/shared/sdk';
import { FStorageService } from 'src/app/providers/f-storage.service';
import { ChatService, PrivacyStatus } from 'src/app/shared/services/chatService';
import { SignalService, MY_ACTION } from 'src/app/shared/services/signal.service';
import { RoutingStateService } from 'src/app/shared/services/routing-state.service';
import { ToasterService } from 'src/app/providers/toaster.service';
import { Subscription } from 'rxjs';
import { AlbumService } from 'src/app/shared/services/album.service';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { MyFileService, PHOTOSOURCE } from 'src/app/shared/services/my-file.service';
import { FileEntry } from '@ionic-native/file/ngx';
import { InputFileOptions, MineTypeEnum } from '@wkoza/ngx-upload';
import { FileItem, HttpClientUploadService } from '@wkoza/ngx-upload';
import { HttpHeaders } from '@angular/common/http';
import { PhotoViewer } from '@ionic-native/photo-viewer/ngx';


@Component({
  selector: 'app-chat-private',
  templateUrl: './chat-private.page.html',
  styleUrls: ['./chat-private.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatPrivatePage implements OnInit {

  phone_model = 'android';
  input = '';
  input_to_send = '';

  // conversation: ChatMessage[] = [];
  messageQueue: ChatMessage[] = [];
  userName: any;
  // user_input = '';

  _sender: FameUser;
  _receiver: FameUser;
  senderImage = '';
  receiverImage = '';


  start_typing: any;
  loader: boolean;


  _chat: ChatObj;
  _identity: FameIdentity;
  _loading: HTMLIonLoadingElement;


  _channelId = '';
  _chatRoom: ChatRoom;

  newChatChannel$: Subscription;

  receive$: Subscription;

  _emojiSheetToggle = false;

  @ViewChild(IonContent) content: IonContent;

  // optionsInput: InputFileOptions = {
  //   multiple: true,
  //   accept: [MineTypeEnum.Image, MineTypeEnum.Application_Pdf, MineTypeEnum.Audio, MineTypeEnum.Video]
  // };

  @Input()
  ngxInputFile: InputFileOptions;

  uploadUrl = '';
  // headers: HttpHeaders = {
  //   me
  // }


  changeTrigger = 0;

  constructor(
    private platform: Platform,
    public alertController: AlertController,
    private device: Device,
    private _fstore: FStorageService,
    private menuCtrl: MenuController,
    public _route: ActivatedRoute,
    private _chatService: ChatService,
    private _router: Router,
    private _signal: SignalService,
    public _routingState: RoutingStateService,
    public _alert: AlertController,
    private _loadCtrl: LoadingController,
    private _toaster: ToasterService,
    private _albumService: AlbumService,
    private _keyboard: Keyboard,
    private _fs: MyFileService,
    public uploader: HttpClientUploadService,
    private _photoViewer: PhotoViewer,
    private cdr: ChangeDetectorRef
  ) {
    this._route.params.subscribe(params => {
      if (params.channelId) {
        this._channelId = params.channelId;
        this.init();
      }
    });
  }

  async ngOnInit() {
    this._fstore.getObject('user').then(_ => {
      this._identity = _;
      if (this._identity && this._identity.fameUser && this._identity.fameUser.location) {
        this._sender = this._identity.fameUser;
        this.getSenderProfilePhoto();
      } else {
        this.showCompleteProfileAlert();
      }
    });

    this._receiver = await this._fstore.getObject('focus_fame_user');
    console.log(this._receiver);
    this.getReceiverProfilePhoto();

    this._signal._action$.subscribe(action => {
      if (action === MY_ACTION.reloadChatRooms) {
        console.log('rooms reloaded');
      }
    });


    // set phone model
    if (this.platform.is('iphone')) {
      this.phone_model = 'iPhone';
    }
    if (this.device.platform === 'iOS') {
      switch (this.platform.height()) {
        case 812:
          this.phone_model = 'iPhone X';
          break;
        case 736:
          this.phone_model = 'iPhone 6/7/8 Plus';
          break;
        case 667:
          this.phone_model = 'iPhone 6/7/8';
          break;
      }
    }

    // File uploader signals
    this.uploader.onCancel$.subscribe(
      (data: FileItem) => {
        console.log('file deleted: ' + data.file);

      });

    this.uploader.onProgress$.subscribe(
      (data: any) => {
        console.log('upload file in progree: ' + data.progress);

      });

    this.uploader.onSuccess$.subscribe(
      (data: any) => {
        console.log(`upload file successful:  ${data.item} ${data.body} ${data.status} ${data.headers}`);
        const fileItem: FileItem = data.item;
        if (this.uploadUrl) {
          const message = new ChatMessage({
            message: fileItem.file.name, read: false, delivered: false,
            sent: false, sender: this._identity.fameUser.fameId,
            channelId: this._channelId, url: this.uploadUrl + 'download/' + fileItem.file.name,
            tracker: Math.floor(Math.random() * 1000000000) // combined with message to for uniqueness
          });
          this._chatService.sendMessage(message);
          this.messageQueue.push(message);
        }

      }
    );

    this.uploader.onAddToQueue$.subscribe((item) => {
      console.log(item);
      console.log('*****************onAddToQueue');
      console.log(this.uploadUrl);
      this.uploader.uploadFileItem(item, { method: 'POST', url: this.uploadUrl + 'upload/' },
        { reportProgress: true, withCredentials: true });
    });
  }


  ionViewDidEnter() {
    this.menuCtrl.enable(false, 'end');
    this.menuCtrl.enable(true, 'start');

    // this.refreshInterval = setInterval(() => {
    //   // after every 30 secs  refresh room
    //   this.refreshRoom();
    // }, 30000);

  }

  async ionViewWillEnter() {
    this._identity = await this._fstore.getObject('user');
    this._receiver = await this._fstore.getObject('focus_fame_user');
    this._signal.sendAction(MY_ACTION.hideHomeTabs);
    // this.getReceiverProfilePhoto();
    if (this._identity && this._identity.fameUser) {
      this._chatService.getUserRooms(this._identity.fameUser.id);
    }
  }

  async ionViewWillLeave() {
    this._signal.sendAction(MY_ACTION.showHomeTabs);
  }


  async init() {
    this._loading = await this._loadCtrl.create({
      message: 'Initializing chat...'
    });
    setTimeout(_ => {
      this._loading.dismiss();
    }, 10000); // for 10 seconds
    await this._loading.present();

    // subscribe to incomming private chat request.
    this.newChatChannel$ = this._signal._newChatChannel$.subscribe(channel => {
      this._channelId = channel;
      // load messages
      this.getRoom();
    });

    if (this._channelId) {
      // this._signal.incommingNewChatChannel(this._channelId);
      this.getRoom();
    } else if (this._receiver && this._receiver.identity) {
      this._chatService.initPrivateChat({
        senderId: this._identity.id,
        receiverId: this._receiver.identity.id, // identity id
        privacyStatus: PrivacyStatus.private
      });
    } else {
      // Invalid receiver
      // go back
      this._router.navigateByUrl(this._routingState.getPreviousUrl());
    }
  }


  send() {
    if (this.input !== '' && this.input !== '') {
      const message = new ChatMessage({
        message: this.input, read: false, delivered: false,
        sent: false, sender: this._identity.fameUser.fameId,
        channelId: this._channelId,
        tracker: Math.floor(Math.random() * 1000000000) // combined with message for uniqueness
      });

      this._chatService.sendMessage(message);
      this.messageQueue.push(message);
      this.input = '';
    }
  }

  // Recieve and  Update message as read
  receive() {
    this.receive$ = this._chatService.receiveMessage(this._channelId).subscribe((message: ChatMessage) => {
      console.log(message);
      let isUpdate = false;
      // delete object from queue
      this.messageQueue.forEach((msg, index) => {
        if ((message.id === msg.id) || (message.message.indexOf(msg.message) > -1 &&
          message.sender === msg.sender && message.tracker === msg.tracker)) {
          // replace with the newly replaced received
          this.messageQueue[index] = message;
          this.cdr.markForCheck();
          this.refreshRoom();
          isUpdate = true;
          console.log('update');

          // update old messages as read
          if (msg.tracker && msg.id && !msg.read &&
            msg.sender !== this._identity.fameUser.fameId) {
            msg.read = true;
            this._chatService.markMessageAsRead(msg);
            console.log('marking as read');
          }
        }
      });
      if (message.tracker && message.id && !message.read &&
        message.sender !== this._identity.fameUser.fameId) {
        message.read = true;
        this._chatService.markMessageAsRead(message);
        console.log('marking as read');
      }
      if (!isUpdate) {
        this.messageQueue.push(message);
        this.cdr.markForCheck();
        this.refreshRoom();
      }
      this.content.scrollToBottom();
    });
  }

  refreshRoom() {
    const temp = this.messageQueue;
    this.messageQueue = [];
    this.cdr.detectChanges();
    this.messageQueue = temp;
    this.cdr.detectChanges();
    setTimeout(_ => {
      this.content.scrollToBottom();
    }, 1000);
  }

  getRoom() {
    if (this._loading) {
      this._loading.innerText = 'Fetching messages...';
    }

    this._chatService.getRoomByChannel(this._channelId).subscribe((room: ChatRoom) => {
      this._chatRoom = room;
      console.log(room);

      if (room && room.privacyStatus === PrivacyStatus.private) {
        // load receiver
        if (!this._receiver) {
          for (const user of room.fameUsers) {
            if (user.id !== this._identity.fameUser.id) {
              this._receiver = user;
            }
          }
        }
        // load previous messages
        if (room.messages.length > 0) {
          this.messageQueue = room.messages.reverse();
          this.cdr.markForCheck();
          this.content.scrollToBottom();

        }
        if (this._receiver) {
          // open chat connection
          this._chatService.initPrivateChat({
            senderId: this._identity.id,
            receiverId: this._receiver.identity.id, // identity id
            privacyStatus: PrivacyStatus.private,
            channelId: this._channelId
          });

          // subscribe to incoming  messages
          this.receive();
        } else {
          this._toaster.toast('Invalid receipient');
        }

        this.uploadUrl = this._fs.CONTAINER_ROOT + room.id + room.channelId + '/';
      }
      this.refreshRoom();
      this._loading.dismiss();
    }, error => {
      console.log(error);
      this._toaster.toast('Initialization failed.');
      this._router.navigateByUrl(this._routingState.getPreviousUrl());
    });
  }

  showCompleteProfileAlert() {
    this._alert.create({
      header: 'Alert!',
      message: 'To initialize private chat, you need to complete profile',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            this._router.navigateByUrl(this._routingState.getPreviousUrl());
          }
        }, {
          text: 'Yes',
          handler: () => {
            this._router.navigate(['/create-profile-location', { returnUrl: '/chat-private' }]);
          }
        }
      ]
    }).then(alert => alert.present());
  }

  isSender(msg: ChatMessage) {
    if (msg.sender === this._identity.fameUser.fameId) {
      return true;
    }
    return false;
  }

  getReceiverProfilePhoto() {
    console.log(this._receiver);
    if (this._receiver) {
      this._albumService.getUserDefaultCover(this._receiver).then(pic => {
        this.receiverImage = pic;
      });
    }
  }

  getSenderProfilePhoto() {
    if (this._identity && this._identity.fameUser) {
      this._albumService.getUserDefaultCover(this._identity.fameUser).then(pic => {
        this.senderImage = pic;
      });
    }
  }

  isPrevMsgOwner(index: number) {
    // console.log(index);
    if (index > 1 && this.messageQueue && (this.messageQueue.length > 1) &&
      (this.messageQueue[index].sender === this.messageQueue[index - 1].sender)) {
      return true;
    }
    return false;
  }

  toggleEmojiSheet() {
    this._emojiSheetToggle ? this._emojiSheetToggle = false : this._emojiSheetToggle = true;
  }

  addEmoji($evt) {
    console.log($evt);
    this.input += $evt.emoji.native;
  }

  showKeyboard() {
    this._keyboard.show();
    this.refreshRoom();
    this._emojiSheetToggle = false;
  }

  hideKeyboard() {
    this._keyboard.hide();
  }

  attach() {
    // this.uploader.queue.forEach(item => {
    // });
  }

  uploadFileRemote(file: FileEntry) {
    this._fs.upload(file.nativeURL, file.name, this._chatRoom.id + '' + this._chatRoom.channelId).then(data => {
      console.log(data);
      if (this.uploadUrl) {
        const message = new ChatMessage({
          message: file.name, read: false, delivered: false,
          sent: false, sender: this._identity.fameUser.fameId,
          channelId: this._channelId, url: this.uploadUrl + 'download/' + file.name,
          tracker: Math.floor(Math.random() * 1000000000) // combined with message to for uniqueness
        });
        this._chatService.sendMessage(message);
        this.messageQueue.push(message);
      }
    }, error => {
      console.log(error),
        this._toaster.toast('Upload failed | Check network');
      this._loading.dismiss();
    });
  }


  uploadPhoto() {
    const sub = this._fs._fileEntry$.subscribe(
      image => {
        // console.log(image);
        this.uploadFileRemote(image);
        sub.unsubscribe();
      },
      error => {
        this._loading.dismiss();
        this._toaster.toast('Image upload failed');
      }
    );
    this._fs.takePicture().then(_ => {
      console.log(_);
      this._loading.dismiss();
    }, error => {
      console.log(error);
      this._loading.dismiss();
    });
  }

  isImage(conv: ChatMessage) {
    if (conv && conv.url) {
      const temp = conv.url.split('.');
      const file_ext = temp[temp.length - 1];
      const exts = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff'];
      if (exts.includes(file_ext.toLowerCase())) {
        return true;
      }
    }
  }

  isVideo(conv: ChatMessage) {
    if (conv && conv.url) {
      const temp = conv.url.split('.');
      const file_ext = temp[temp.length - 1];
      const exts = ['mp4', 'mp2', 'mpeg', 'mpv', 'avi', 'mov', 'flv', 'swf', 'wmv', 'webm', 'mkv', '3gp'];
      if (exts.includes(file_ext.toLowerCase())) {
        return true;
      }
    }
  }

  isAudio(conv: ChatMessage) {
    if (conv && conv.url) {
      const temp = conv.url.split('.');
      const file_ext = temp[temp.length - 1];
      const exts = ['wav', 'ogg', 'mp3'];
      if (exts.includes(file_ext.toLowerCase())) {
        return true;
      }
    }
  }

  getExt(url: string) {
    if (url) {
      const temp = url.split('.');
      return temp[temp.length - 1];
    }
    return '';
  }

  viewPhoto(conv: ChatMessage) {
    this._photoViewer.show(conv.url, conv.message, { share: true });
  }

  // calcEndTime(date: Date, durationInMin: number) {
  //   const date_number = (new Date(date).getTime() + (durationInMin * 60 * 1000));
  //   return new Date(date_number);
  // }

  gotoChats() {
    this._router.navigate(['/chat-home', { page: 'chat' }]);
  }
  gotoGroups() {
    this._router.navigate(['/chat-home', { page: 'group' }]);
  }

}
