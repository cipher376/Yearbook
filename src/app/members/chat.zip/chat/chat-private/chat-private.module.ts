/**
 * Chatter - Chat themes Ionic 4 (https://www.enappd.com)
 *
 * Copyright © 2018-present Enappd. All rights reserved.
 *
 * This source code is licensed as per the terms found in the
 * LICENSE.md file in the root directory of this source .
 *
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';
import { PickerModule } from '@ctrl/ngx-emoji-mart';
import { ChatPrivatePage } from './chat-private.page';
import { EmojiModule } from '@ctrl/ngx-emoji-mart/ngx-emoji';
import { NgxUploadModule } from '@wkoza/ngx-upload';

// import { VideoPlayerPage } from './video-player.page';
import { VgCoreModule } from 'videogular2/core';
import { VgControlsModule } from 'videogular2/controls';
import { VgOverlayPlayModule } from 'videogular2/overlay-play';
import { VgBufferingModule } from 'videogular2/buffering';
import { PipeModule } from 'src/app/pipes/pipe/pipe.module';

const routes: Routes = [
  {
    path: '',
    component: ChatPrivatePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipeModule,
    RouterModule.forChild(routes),
    PickerModule,
    EmojiModule,
    NgxUploadModule,
    VgCoreModule,
    VgControlsModule,
    VgOverlayPlayModule,
    VgBufferingModule
  ],
  declarations: [ChatPrivatePage]
})
export class ChatPrivatePageModule { }
