import { User } from 'src/app/models/user';


export interface ChatRoomInterface {
  'id'?: any;
  'title'?: string;
  'privacyStatus': number;
  'roomStatus'?: number;
  'channelId': string;
  messages?: ChatMessage[];
}
export class ChatRoom implements ChatRoomInterface {
  'id': any;
  'title': string;
  'privacyStatus': number;
  'roomStatus': number;
  'channelId': string;
  messages: ChatMessage[];
  users: User[];
  constructor(data?: ChatRoomInterface) {
    Object.assign(this, data);
  }
}
export interface ChatMessageInterface {
  'id'?: any;
  'message': string;
  'url'?: string;
  'sender'?: string;
  'read': boolean;
  'delivered': boolean;
  'sent': boolean;
  'channelId': string;
  'tracker': number;
  'dateCreated'?: Date;
  'dateModified'?: Date;
  'roomId'?: any;
  room?: ChatRoom;
}

export class ChatMessage implements ChatMessageInterface {
  'id': any;
  'message': string;
  'url': string;
  'sender': string;
  'read': boolean;
  'delivered': boolean;
  'sent': boolean;
  'channelId': string;
  'tracker': number;
  'dateCreated': Date;
  'dateModified': Date;
  'roomId': any;
  room: ChatRoom;
  constructor(data?: ChatMessageInterface) {
    Object.assign(this, data);
  }
}
export interface ChatObj {
  name: string;
  image: string;
  description: string;
  count?: string | undefined;
  time: string;
  messages?: ChatMessage[];
  channelId: string;
}
