import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ChatRoom, FameUser, FameIdentity, ChatMessage } from 'src/app/shared/sdk';
import { ChatObj } from '../models/chat';
import { FStorageService } from 'src/app/providers/f-storage.service';
import { LoadingController } from '@ionic/angular';
import { ChatService, PrivacyStatus } from 'src/app/shared/services/chatService';
import { MyFileService } from 'src/app/shared/services/my-file.service';
import { AlbumService } from 'src/app/shared/services/album.service';
import { SignalService, MY_ACTION } from 'src/app/shared/services/signal.service';
import { FriendshipService } from 'src/app/shared/services/friendship.service';
import { ToasterService } from 'src/app/providers/toaster.service';
import { RoutingStateService } from 'src/app/shared/services/routing-state.service';

@Component({
  selector: 'app-chat-home',
  templateUrl: './chat-home.page.html',
  styleUrls: ['./chat-home.page.scss'],
})
export class ChatHomePage implements OnInit {
  _loading: HTMLIonLoadingElement;
  _identity: FameIdentity;
  _userCoverImages: string[] = [];

  segmentTab: any;
  chatData: ChatObj[] = [];

  privateChats: ChatRoom[] = [];
  publicChats: ChatRoom[] = [];

  _searchResult: any[] = [];
  _isSearchOn = false;

  _friends: FameUser[] = [];
  _friendsMessages: ChatMessage[] = [];

  constructor(
    public route: Router,
    private _fstore: FStorageService,
    private _loadCtrl: LoadingController,
    private _router: Router,
    private _route: ActivatedRoute,
    private _chatService: ChatService,
    private _albumService: AlbumService,
    private _signal: SignalService,
    private _friendServices: FriendshipService,
    private _toaster: ToasterService,
    public _routingState: RoutingStateService,
  ) {
    // Load user private and public chats.
    this.chatData = [];
    // const prevUrl = this._routingState.getPreviousUrl();
  }

  async ngOnInit() {
    this._loading = await this._loadCtrl.create({
      message: 'Loading...'
    });

    this._fstore.getObject('user').then(_ => {
      this._identity = _;
    });

    setTimeout(_ => {
      this._loading.dismiss();
    }, 1000);
    await this._loading.present();

    this._signal._action$.subscribe(action => {
      if (action === MY_ACTION.reloadFriends) {
        this.reload().then(_ => _);
      } else if (action === MY_ACTION.reloadChatRooms) {
        this._chatService.getRoomsLocal().then((rooms: ChatRoom[]) => {
          if (rooms && rooms.length > 0) {
            this.privateChats = [];
            this.publicChats = [];
            rooms.forEach(room => {
              if (room.privacyStatus === PrivacyStatus.private) {
                this.privateChats.push(room);
              } else if (room.privacyStatus === PrivacyStatus.public) {
                this.publicChats.push(room);
              }
            });
          }
        });
      }

    });

    // this.reload(); // get friends from disk
  }

  ionViewDidEnter() {
    const page = this._route.snapshot.paramMap.get('page');
    // console.log(page);
    if (page) {
      this.segmentTab = page;
    }
    if (this._identity && this._identity.fameUser) {
      this._friendServices.getFriends(this._identity.fameUser.id).subscribe((friends: FameUser[]) => {
      });

      // trigger rooms reload
      this._chatService.getUserRooms(this._identity.fameUser.id).subscribe(_ => _);
    }
  }


  segmentChanged(event: any) {
    this.segmentTab = event.detail.value;
    console.log(this.segmentTab);
  }

  async goforPrivateChat(receiverFameUser: FameUser) {
    this._chatService.goforPrivateChat(receiverFameUser).then(_ => _);
  }


  toggleSearch() {
    this._isSearchOn = !this._isSearchOn;
    if (this._isSearchOn) {
      this.scrollToTop();
    }
  }

  scrollToTop() {
    // this.content.scrollToTop(1000);
  }

  async getUserCoverPhotos(users: FameUser[]) {
    return new Promise((resolve, reject) => {
      const userPhotos: string[] = [];
      let i = 0;
      users.forEach(user => {
        this._albumService.getUserDefaultCover(user).then(photo => {
          this._userCoverImages.push(photo);
          i += 1;
          if (i >= users.length) {
            resolve(true);
          }
        });
      });
    });
  }


  LoadChatObjects() {

  }



  async goToProfile(user: FameUser) {
    console.log(user);
    await this._fstore.setObject('focus_fame_user', user);
    this._signal.sendAction(MY_ACTION.newFocusUser);
    this._router.navigateByUrl('/view-profile');
  }


  search() {

  }

  async reload() {
    console.log('reloading friends');
    this._friendServices.getFriendsLocal().then((fnds: FameUser[]) => {
      console.log(fnds);
      if (fnds && fnds.length > 0) {
        this._friends = fnds;
        this.getUserCoverPhotos(this._friends);
      }
    });

  }

  getLastUnreadMsg(room: ChatRoom) {
    if (room) {
      const friend = this.getFriendPrivate(room);

      const msgs: ChatMessage[] = [];
      if (room.messages && room.messages.length > 0) {
        for (let i = (room.messages.length - 1); i >= 0; i--) {
          if (!room.messages[i].read && room.messages[i].sender !== this._identity.fameUser.fameId) {
            msgs.push(room.messages[i]);
          }
          if (i > 50) {
            break;
          }
        }
      }

      if (msgs.length > 0) {
        return {
          unread_count: msgs.length, lastMsg: (msgs[0]).message, friendName:
            friend ? friend.name.first + ' ' + friend.name.last : '', time: msgs[0].dateCreated
        };
      } else if (room.messages && room.messages.length > 0) {
        return {
          unread_count: 0, lastMsg: (room.messages[room.messages.length - 1]).message,
          friendName: friend ? friend.name.first + ' ' + friend.name.last : '', time: room.messages[room.messages.length - 1].dateCreated
        };
      }
    }
    return { unread_count: 0, lastMsg: '', friendName: '', time: new Date() };
  }


  getFriendPrivate(room: ChatRoom) {
    if (room && room.fameUsers && room.fameUsers.length > 0) {
      for (let i = 0; i < room.fameUsers.length; i++) {
        if (room.fameUsers[i].id !== this._identity.fameUser.id) {
          return room.fameUsers[i];
        }
      }
    }
  }
}
